<h3>REPORTE DE USUARIO POR PAIS</h3>
<?php $respuesta = $info ?>

<table border="1">
    <thead>
        <th>Cod. pais</th>
        <th>Cantidad</th>
    </thead>
    <tbody>
        <?php $__currentLoopData = $respuesta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($row->pais); ?>

                </td>
                <td>
                    <?php echo e($row->cantidad); ?>

                </td>
            </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>

</table>
<?php /**PATH C:\xampp\htdocs\laravel\users\usuarios\resources\views/emails/reporte.blade.php ENDPATH**/ ?>