<div class="box box-info padding-1">
    <div class="box-body">

        <div class="form-group">
            <?php echo e(Form::label('categoria_id')); ?>

            <?php echo e(Form::select('categoria_id', $categorias ,$usuario->categoria_id, ['class' => 'form-control' . ($errors->has('categoria_id') ? ' is-invalid' : ''), 'placeholder' => 'Categoria Id'])); ?>

            <?php echo $errors->first('categoria_id', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

        <div class="form-group">
            <?php echo e(Form::label('nombres')); ?>

            <?php echo e(Form::text('nombres', $usuario->nombres, ['class' => 'form-control' . ($errors->has('nombres') ? ' is-invalid' : ''), 'placeholder' => 'Nombres'])); ?>

            <?php echo $errors->first('nombres', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('apellidos')); ?>

            <?php echo e(Form::text('apellidos', $usuario->apellidos, ['class' => 'form-control' . ($errors->has('apellidos') ? ' is-invalid' : ''), 'placeholder' => 'Apellidos'])); ?>

            <?php echo $errors->first('apellidos', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('cedula')); ?>

            <?php echo e(Form::text('cedula', $usuario->cedula, ['class' => 'form-control' . ($errors->has('cedula') ? ' is-invalid' : ''), 'placeholder' => 'Cedula'])); ?>

            <?php echo $errors->first('cedula', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('email')); ?>

            <?php echo e(Form::email('email', $usuario->email, ['class' => 'form-control' . ($errors->has('email') ? ' is-invalid' : ''), 'placeholder' => 'Email'])); ?>

            <?php echo $errors->first('email', '<div class="invalid-feedback">:message</div>'); ?>

        </div>


        <div class="form-group">
            <?php echo e(Form::label('pais')); ?>

            <?php echo e(Form::select('pais', $paises , $usuario->pais, ['class' => 'form-control' . ($errors->has('pais') ? ' is-invalid' : ''), 'placeholder' => 'Pais'])); ?>

            <?php echo $errors->first('pais', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

        <div class="form-group">
            <?php echo e(Form::label('direccion')); ?>

            <?php echo e(Form::text('direccion', $usuario->direccion, ['class' => 'form-control' . ($errors->has('direccion') ? ' is-invalid' : ''), 'placeholder' => 'Direccion'])); ?>

            <?php echo $errors->first('direccion', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('celular')); ?>

            <?php echo e(Form::number('celular', $usuario->celular, ['class' => 'form-control' . ($errors->has('celular') ? ' is-invalid' : ''), 'placeholder' => 'Celular'])); ?>

            <?php echo $errors->first('celular', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Guardar</button>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel\users\usuarios\resources\views/usuario/form.blade.php ENDPATH**/ ?>