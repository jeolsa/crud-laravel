<p>Se registró su usuario correctamente.</p>
<?php /**PATH C:\xampp\htdocs\laravel\users\usuarios\resources\views/emails/registrousuario.blade.php ENDPATH**/ ?>