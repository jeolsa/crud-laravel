<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;

/**
 * Class Usuario
 *
 * @property $id
 * @property $categoria_id
 * @property $nombres
 * @property $apellidos
 * @property $cedula
 * @property $email
 * @property $pais
 * @property $direccion
 * @property $celular
 * @property $created_at
 * @property $updated_at
 *
 * @property Categoria $categoria
 * @package App
 * @mixin \Illuminate\Database\Eloquent\Builder
 */
class Usuario extends Model
{
    use Notifiable;

    static $rules = [
		'categoria_id' => 'required',
		'nombres' => 'required|max:100|min:5|regex:/^[\pL\s\-]+$/u',
		'apellidos' => 'required|max:100|regex:/^[\pL\s\-]+$/u',
		'cedula' => 'required|unique:usuarios,cedula,id',
		'email' => 'required|max:150|unique:usuarios,email,id',
		'pais' => 'required',
		'direccion' => 'required|max:180',
		'celular' => 'required|max:10',
    ];

    protected $perPage = 20;

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['categoria_id','nombres','apellidos','cedula','email','pais','direccion','celular'];


    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function categoria()
    {
        return $this->hasOne('App\Models\Categoria', 'id', 'categoria_id');
    }


}
