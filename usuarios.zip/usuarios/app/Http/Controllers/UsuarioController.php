<?php

namespace App\Http\Controllers;

use App\Events\EnviarCorreos;
use App\Events\Reporte;
use App\Models\Usuario;
use App\Models\Categoria;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\DB;

/**
 * Class UsuarioController
 * @package App\Http\Controllers
 */
class UsuarioController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $usuarios = Usuario::paginate();

        return view('usuario.index', compact('usuarios'))
            ->with('i', (request()->input('page', 1) - 1) * $usuarios->perPage());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $paises = [];
        $respuesta = Http::get("https://restcountries.com/v3.1/region/ame")->json();

        foreach($respuesta as $row){
            $nombre = $row["name"]["common"];
            array_push($paises, $nombre);
        }

        $usuario = new Usuario();
        $categorias = Categoria::pluck('nombre','id');
        return view('usuario.create', compact('usuario','categorias', 'paises'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate( [
            'categoria_id' => 'required',
            'nombres' => 'required|max:100|min:5|regex:/^[\pL\s\-]+$/u',
            'apellidos' => 'required|max:100|regex:/^[\pL\s\-]+$/u',
            'cedula' => 'required|unique:usuarios,cedula,id',
            'email' => 'required|max:150|unique:usuarios,email,id',
            'pais' => 'required',
            'direccion' => 'required|max:180',
            'celular' => 'required|max:10',
        ]);

        $usuario = Usuario::create($request->all());

        $sql = 'SELECT pais, COUNT(*) as cantidad FROM usuarios GROUP BY pais';
        $datos = DB::select($sql);

        event(new EnviarCorreos($usuario));
        event(new Reporte($datos));

        return redirect()->route('usuarios.index')
            ->with('success', 'Usuario created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $usuario = Usuario::find($id);

        return view('usuario.show', compact('usuario'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $paises = [];
        $respuesta = Http::get("https://restcountries.com/v3.1/region/ame")->json();

        foreach($respuesta as $row){
            $nombre = $row["name"]["common"];
            array_push($paises, $nombre);
        }

        $usuario = Usuario::find($id);
        $categorias = Categoria::pluck('nombre','id');

        return view('usuario.edit', compact('usuario','categorias', 'paises'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  Usuario $usuario
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Usuario $usuario)
    {
        request()->validate( [
            'categoria_id' => 'required',
            'nombres' => 'required|max:100|min:5|regex:/^[\pL\s\-]+$/u',
            'apellidos' => 'required|max:100|regex:/^[\pL\s\-]+$/u',
            'cedula' => 'required|unique:usuarios,cedula,'.$usuario->id,
            'email' => 'required|max:150|unique:usuarios,email,'.$usuario->id,
            'pais' => 'required',
            'direccion' => 'required|max:180',
            'celular' => 'required|max:10',
        ]);

        $usuario->update($request->all());

        return redirect()->route('usuarios.index')
            ->with('success', 'Usuario updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $usuario = Usuario::find($id)->delete();

        return redirect()->route('usuarios.index')
            ->with('success', 'Usuario deleted successfully');
    }
}
