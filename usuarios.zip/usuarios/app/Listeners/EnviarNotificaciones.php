<?php

namespace App\Listeners;

use App\Events\EnviarCorreos;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Notification;
use Illuminate\Queue\InteractsWithQueue;
use App\Models\Usuario;
use Illuminate\Support\Facades\Mail as Mails;
use Mail;

class EnviarNotificaciones
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  \App\Events\EnviarCorreos  $event
     * @return void
     */
    public function handle(EnviarCorreos $event)
    {
        //


        $usuario = $event->usuario;

        $data = [
            "id" => $usuario['id'],
            "email" => $usuario['email'],
        ];

        Mails::send('emails.registrousuario', $data, function ($message) use ($data) {
            $message->from('olivaresjeisson@gmail.com', 'Jeisson Olivares');
            $message->to($data['email']);
            $message->subject('Registro de usuario');
            $message->priority(3);
        });
    }
}
