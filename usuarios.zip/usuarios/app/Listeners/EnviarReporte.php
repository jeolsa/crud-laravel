<?php

namespace App\Listeners;

use App\Events\Reporte;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use App\Models\Usuario;
use Illuminate\Support\Facades\Mail as Mails;


class EnviarReporte
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  \App\Events\enviarReporte  $event
     * @return void
     */
    public function handle(Reporte $event)
    {
        //
        $emailAdm = "olivaresjeisson@gmail.com";

        $info = $event->datos;

        $data = [
            "info" => $info,
            "email" => $emailAdm,
        ];

        var_dump($info);

        Mails::send('emails.reporte', $data, function ($message) use ($data) {
            $message->from('olivaresjeisson@gmail.com', 'Jeisson Olivares');
            $message->to($data['email']);
            $message->subject('Reporte de usuario');
            $message->priority(3);
        });
    }
}
