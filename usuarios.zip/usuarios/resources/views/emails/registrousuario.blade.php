<p>Se registró su usuario correctamente.</p>
