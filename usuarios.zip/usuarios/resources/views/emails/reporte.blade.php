<h3>REPORTE DE USUARIO POR PAIS</h3>
<?php $respuesta = $info ?>

<table border="1">
    <thead>
        <th>Cod. pais</th>
        <th>Cantidad</th>
    </thead>
    <tbody>
        @foreach($respuesta as $row)
            <tr>
                <td>
                    {{$row->pais}}
                </td>
                <td>
                    {{$row->cantidad}}
                </td>
            </tr>

        @endforeach

    </tbody>

</table>
